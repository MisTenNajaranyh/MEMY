HentAPI
========

**HentAPI - hentai api, works only in python.**

How to install:
--------

.. code:: sh

    $ cd /path-to-bot-files/
    $ git clone https://github.com/MisTenNajaranyh/MEMY.git
    $ thats all

Documentation:
--------
.. code:: py

    from MEMY import memy

    hentai.randomHentai() #gives a random image url

.. code:: py

    from MEMY import memy

    hentai.sendWebhook(url="webhook url", name="webhook name [optional]", avatar="webhook avatar url [optional]") #webhook send a random image in embed

Links:
--------
- Discord - https://discord.gg/9shvrQ2
